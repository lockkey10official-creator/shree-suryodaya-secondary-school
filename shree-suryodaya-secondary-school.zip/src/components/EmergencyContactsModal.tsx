import React, { useState } from 'react';
import { X, Phone, Building, UserCheck, Bus, CreditCard, HeartPulse, Copy, Check } from 'lucide-react';
import { Language, translations } from '../i18n/translations';

interface EmergencyContactsModalProps {
  lang: Language;
  onClose: () => void;
}

export const EmergencyContactsModal: React.FC<EmergencyContactsModalProps> = ({
  lang,
  onClose
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const t = translations[lang];

  const contacts = [
    {
      id: 'c1',
      title: t.principalOffice,
      person: "Mr. Ram Bahadur Thapa (Principal)",
      phone: "+977-9851234567",
      icon: UserCheck,
      color: "bg-blue-600"
    },
    {
      id: 'c2',
      title: t.examController,
      person: "Mrs. Sita Adhikari (Exam Head)",
      phone: "+977-9841987654",
      icon: Building,
      color: "bg-indigo-600"
    },
    {
      id: 'c3',
      title: t.busTransport,
      person: "Mr. Bikram Shrestha (Transport Manager)",
      phone: "+977-9801122334",
      icon: Bus,
      color: "bg-amber-600"
    },
    {
      id: 'c4',
      title: t.accountsDepartment,
      person: "Account Desk Counter 1",
      phone: "+977-011-440123",
      icon: CreditCard,
      color: "bg-emerald-600"
    },
    {
      id: 'c5',
      title: t.medicalEmergency,
      person: "Staff Nurse First Aid Room",
      phone: "+977-9860001122",
      icon: HeartPulse,
      color: "bg-red-600"
    }
  ];

  const handleCopy = (id: string, num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500 text-slate-950 font-bold shadow">
              <Phone className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-white">
                {t.emergencyContactsTitle}
              </h3>
              <p className="text-xs text-slate-400">Direct School Helpline & Helpdesks</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contacts List */}
        <div className="p-6 space-y-3 overflow-y-auto max-h-[60vh]">
          {contacts.map((c) => {
            const Icon = c.icon;
            const isCopied = copiedId === c.id;

            return (
              <div
                key={c.id}
                className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 border border-slate-200 hover:border-blue-300 transition"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-2xl text-white shadow ${c.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{c.title}</h4>
                    <p className="text-xs text-slate-500 font-medium">{c.person}</p>
                    <p className="text-xs font-bold text-blue-800 mt-0.5">{c.phone}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <a
                    href={`tel:${c.phone}`}
                    className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white transition shadow text-xs font-bold"
                    title="Call Now"
                  >
                    <Phone className="w-4 h-4" />
                  </a>

                  <button
                    onClick={() => handleCopy(c.id, c.phone)}
                    className="p-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 transition"
                    title="Copy Phone"
                  >
                    {isCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition cursor-pointer"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
