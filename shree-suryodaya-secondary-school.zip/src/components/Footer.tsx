import React from 'react';
import { GraduationCap, Phone, Calendar, ShieldCheck, MapPin, Globe } from 'lucide-react';
import { Language, translations } from '../i18n/translations';

interface FooterProps {
  lang: Language;
  onOpenEmergency: () => void;
  onOpenCalendar: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  lang,
  onOpenEmergency,
  onOpenCalendar,
  onOpenAdmin
}) => {
  const t = translations[lang];

  return (
    <footer className="bg-slate-950 text-slate-300 pt-12 pb-8 border-t border-slate-800 mt-16">
      <div className="max-w-7xl mx-auto px-6 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-slate-800">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-amber-500 text-slate-950 font-bold shadow">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-extrabold text-white">
                  {t.schoolName}
                </h3>
                <p className="text-xs text-amber-400 font-semibold">{t.schoolNameNepali}</p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-md">
              {t.tagline}. Dedicated to providing quality public secondary education, holistic discipline, and academic excellence in Nepal.
            </p>

            <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
              <MapPin className="w-4 h-4 text-amber-400" />
              <span>{t.location}</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Quick Navigation</h4>
            <ul className="space-y-1.5 text-xs text-slate-400 font-medium">
              <li>
                <button onClick={onOpenCalendar} className="hover:text-amber-300 transition">
                  {t.schoolCalendar}
                </button>
              </li>
              <li>
                <button onClick={onOpenEmergency} className="hover:text-amber-300 transition">
                  {t.emergencyContactsTitle}
                </button>
              </li>
              <li>
                <button onClick={onOpenAdmin} className="hover:text-amber-300 transition">
                  {t.navAdmin}
                </button>
              </li>
            </ul>
          </div>

          {/* Affiliation */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Government Approval</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              {t.footerAffiliation}
            </p>
            <p className="text-xs text-amber-400/90 font-mono">
              School Code: 24001 • NEB Affiliation No: 914
            </p>
          </div>
        </div>

        {/* Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
          <p>{t.copyright}</p>
          <p className="text-slate-600">PWA & Offline Caching Enabled</p>
        </div>
      </div>
    </footer>
  );
};
